# two programs are there

### term.cpp - is a terminal based interactive design
		make using the command 'make all'
		run using './term.out'
		create and run testcases using 'make test'

### gui.cpp - can be used to visualize the race in real time
		make using 'make gui'
		run using './gui'